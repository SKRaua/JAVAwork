package YuZhangproject5;

/**
 * @Author YuZhang
 * @Date 2023/5/27
 *       Version 1.0
 */
public class InvalidTriangleException extends Exception {
    public InvalidTriangleException(String message) {
        // Call super constructor with the parameter message.
        super(message);
    }
}
