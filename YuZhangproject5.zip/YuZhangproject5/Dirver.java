package YuZhangproject5;

import java.io.FileNotFoundException;

/**
 * @Author YuZhang
 * @Date 2023/5/27
 *       Version 1.0
 */
public class Dirver {
    public static void main(String[] args) throws FileNotFoundException {
        Test.start();
    }
}
