package XinYangZhouProject05;

public class InvalidTriangleException extends Exception {
    public InvalidTriangleException(String message) {
        // Call super constructor with the parameter message.
    }
}
