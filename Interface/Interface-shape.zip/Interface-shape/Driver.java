package lab8;

/**
 * Test shape design with a list shapes.
 * @author Qi Wang
 * @version
 */
public class Driver {
	/**
	 * Creates a list of shapes, and displays the areas.
	 * @param args A reference to a string array containing command-line arguments
	 */
	public static void main(String[] args){
		Helper.start();
	}
}

